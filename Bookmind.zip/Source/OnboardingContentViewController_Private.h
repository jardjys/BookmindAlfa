//
//  OnboardingContentViewController.h
//  Onboard
//
//  Created by Hugues Bernet-Rollande on 11/5/15.
//  Copyright (c) 2015 Hugues Bernet-Rollande. All rights reserved.
//

#import "OnboardingContentViewController.h"

@interface OnboardingContentViewController ()

- (void)handleButtonPressed;

@end
